#include "platform.h" /* platform.c llama a xparameters.h */
#include "xil_printf.h"
#include "xtmrctr.h"
#include "xil_cache.h"
#include "xil_io.h"      /* Para el rango de direcciones, ver fichero xsa en directorio hw de la plataforma asociada */
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
/* Memoria de 32K */
bool is_prime(int n) {
    if (n <= 1) {
        return false;
    }
    for (int i = 2; i < n; i++) {
        if (n % i == 0) {
            return false;
        }
    }
    return true;
}


int main()
{
    init_platform(); // Incluye las sentencias de activacion de caches....

    unsigned int time1, time2, diff;
    int i,u32_valor,k;
    int N = 250;
    //int X[250],Y[250];
    XTmrCtr temporizador;

    XTmrCtr_Initialize(&temporizador, 0);
    XTmrCtr_Start(&temporizador, 0);

    time1 = XTmrCtr_GetValue(&temporizador, 0);

    for (i = 0; i < N; i = i + 1)
     {
     	u32_valor = i * 4;
     	Xil_Out32(XPAR_MIG7SERIES_0_BASEADDR + (i * 4), u32_valor);
     };
     /* escribe un valor de 32 bits (u32_valor) en la direcci�n de memoria especificada */

    for (i = 0; i < N; i = i + 1)
    {
	  /* lee un valor de 32 bit de la direcci�n especificada, y lo almacena en u32_valor */
     u32_valor=Xil_In32(XPAR_MIG7SERIES_0_BASEADDR + (i * 4));
     /* Indice casi aleatorio para leer y almacenar datos */
     k=(i/2)+(i % 2) * N / 2;
     //X[k]=Y[i] + u32_valor;
     u32_valor = u32_valor * 2;
     Xil_Out32(XPAR_MIG7SERIES_0_BASEADDR + (k * 4), u32_valor);
    };


	int lower = 1000; // rango inferior
    int upper = 10000; // rango superior
    for (int i = lower; i <= upper; i++) {
        if (is_prime(i)) {
        }
    }


    XTmrCtr_Stop(&temporizador, 0);
    time2 = XTmrCtr_GetValue(&temporizador, 0);

    XTmrCtr_Reset(&temporizador, 0);

    diff = time2 - time1;
    printf(" Numero de ticks usados %u \n\r", diff);



    cleanup_platform();  // Incluye la desactivacion de las caches.
    return 0;
}
